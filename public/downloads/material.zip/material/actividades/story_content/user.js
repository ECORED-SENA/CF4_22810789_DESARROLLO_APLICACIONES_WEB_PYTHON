function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6LjSw3pjBL9":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

